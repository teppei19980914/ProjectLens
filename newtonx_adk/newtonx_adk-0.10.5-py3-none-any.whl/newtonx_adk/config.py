"""
NewtonX ADK 設定管理

NewtonX ADK の設定を管理するクラスを提供します。
"""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:
    from .exceptions import ConfigurationError
except ImportError:
    from exceptions import ConfigurationError


@dataclass
class ADKConfig:
    """ADK 設定クラス"""
    
    # API設定
    host: str = ""
    api_base_url: str = "https://seraku.newton-x.net/api"
    company_subdomain: str = ""
    domain: str = ""  # AADドメイン（例: contoso.onmicrosoft.com）
    
    # 認証設定
    client_id: str = ""
    tenant_id: str = ""
    client_secret: str = ""
    object_id: str = ""
    auth_mode: str = "device_code"
    use_pkce: bool = True
    graph_scopes: list[str] = field(default_factory=lambda: ["User.Read"])  # MSAL予約語(openid, profile, offline_access)は指定しない
    api_scopes: list[str] = field(default_factory=list)
    redirect_uri: str = "http://localhost:8400"
    authority: Optional[str] = None
    # PAT（ADK用トークン）
    personal_access_token: str = ""
    
    # ファイル設定
    token_file: str = "~/.newtonx/tokens.json"
    chat_history_path: str = "~/.newtonx/chats"
    config_file: str = "~/.newtonx/config.json"
    
    # 表示設定
    max_history_display: int = 50
    
    # ネットワーク設定
    timeout: int = 30
    max_retries: int = 3
    auth_timeout: int = 300  # 認証タイムアウト（秒）
    
    # 後方互換性のためのフィールド
    default_assistant: Optional[str] = None


class ConfigManager:
    """設定管理クラス"""
    
    def __init__(self, config_file: Optional[str] = None):
        """
        設定管理クラスの初期化
        
        Args:
            config_file: 設定ファイルのパス（省略時はデフォルト）
        """
        if config_file:
            self.config_file = Path(config_file).expanduser()
        else:
            # 環境変数 NEWTONX_CONFIG_PATH を優先
            import os
            env_path = os.getenv("NEWTONX_CONFIG_PATH")
            if env_path:
                self.config_file = Path(env_path).expanduser()
            else:
                self.config_file = Path("~/.newtonx/config.json").expanduser()
        
        self._config = self._load_config()
    
    def _load_config(self) -> ADKConfig:
        """
        設定ファイルを読み込む
        
        Returns:
            ADKConfig オブジェクト
        """
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    config_data = json.load(f)
                
                # 既知のフィールドのみを抽出してADKConfigを作成
                known_fields = {
                    'host', 'api_base_url', 'company_subdomain', 'domain', 'client_id', 'tenant_id',
                    'client_secret', 'object_id', 'auth_mode', 'use_pkce', 'graph_scopes', 'api_scopes', 'redirect_uri', 'authority',
                    'token_file', 'chat_history_path', 'config_file',
                    'max_history_display', 'timeout', 'max_retries', 'auth_timeout', 'default_assistant',
                    'personal_access_token'
                }
                
                filtered_data = {k: v for k, v in config_data.items() if k in known_fields}
                cfg = ADKConfig(**filtered_data)
                # 読み込み時に正規化
                cfg.api_base_url = self._ensure_api_suffix(cfg.api_base_url)
                # host が設定されている場合は派生値を適用（未設定項目のみ）
                if getattr(cfg, 'host', ""):
                    derived = self._derive_from_host(cfg.host)
                    if not cfg.api_base_url:
                        cfg.api_base_url = derived['api_base_url']
                    if not cfg.company_subdomain:
                        cfg.company_subdomain = derived['company_subdomain']
                return cfg
                
            except Exception as e:
                raise ConfigurationError(f"設定ファイルの読み込みに失敗しました: {e}")
        else:
            # デフォルト設定を返す
            return ADKConfig()
    
    def get_config(self) -> ADKConfig:
        """
        現在の設定を取得する
        
        Returns:
            現在の設定
        """
        return self._config
    
    def save_config(self) -> None:
        """設定を保存する"""
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self._config.__dict__, f, indent=2, ensure_ascii=False)
        except Exception as e:
            raise ConfigurationError(f"設定ファイルの保存に失敗しました: {e}")
    
    def update_config(self, **kwargs) -> None:
        """
        設定を更新する
        
        Args:
            **kwargs: 更新する設定項目
        """
        # host が含まれる場合は先に設定し、派生値を準備
        host_in_updates = 'host' in kwargs and kwargs['host'] is not None and str(kwargs['host']).strip() != ""
        if host_in_updates:
            host_value = str(kwargs['host']).strip()
            self._config.host = host_value
            derived = self._derive_from_host(host_value)
            # 呼び出し側で api_base_url / company_subdomain が未指定なら派生値を充当
            if 'api_base_url' not in kwargs or not kwargs.get('api_base_url'):
                kwargs['api_base_url'] = derived['api_base_url']
            if 'company_subdomain' not in kwargs or not kwargs.get('company_subdomain'):
                kwargs['company_subdomain'] = derived['company_subdomain']

        for key, value in kwargs.items():
            if hasattr(self._config, key):
                setattr(self._config, key, value)
            else:
                raise ConfigurationError(f"不明な設定項目: {key}")
        
        # 末尾 /api の付与を保証
        if getattr(self._config, 'api_base_url', ""):
            self._config.api_base_url = self._ensure_api_suffix(self._config.api_base_url)

        self.save_config()
    
    def set_credentials(self, client_id: str, tenant_id: str, client_secret: str = "") -> None:
        """
        認証情報を設定する
        
        Args:
            client_id: クライアントID
            tenant_id: テナントID
            client_secret: クライアントシークレット（オプション）
        """
        self._config.client_id = client_id
        self._config.tenant_id = tenant_id
        if client_secret:
            self._config.client_secret = client_secret
        
        self.save_config()

    def set_identity(self, *, tenant_id: Optional[str] = None, client_id: Optional[str] = None, domain: Optional[str] = None, object_id: Optional[str] = None) -> None:
        """
        ID関連（EntraID）の識別子をまとめて設定する
        
        Args:
            tenant_id: テナントID
            client_id: クライアントID（アプリケーションID）
            domain: ドメイン（例: contoso.onmicrosoft.com）
            object_id: オブジェクトID（ユーザー/アプリケーション等）
        """
        if tenant_id is not None:
            self._config.tenant_id = tenant_id
        if client_id is not None:
            self._config.client_id = client_id
        if domain is not None:
            self._config.domain = domain
        if object_id is not None:
            self._config.object_id = object_id
        self.save_config()

    def set_auth_options(self, *, use_pkce: Optional[bool] = None, redirect_uri: Optional[str] = None, authority: Optional[str] = None, auth_mode: Optional[str] = None) -> None:
        """
        認証オプションを設定する
        """
        if use_pkce is not None:
            self._config.use_pkce = bool(use_pkce)
        if redirect_uri is not None:
            self._config.redirect_uri = redirect_uri
        if authority is not None:
            self._config.authority = authority
        if auth_mode is not None:
            self._config.auth_mode = auth_mode
        self.save_config()
    
    def set_company_subdomain(self, subdomain: str) -> None:
        """
        会社のサブドメインを設定する
        
        Args:
            subdomain: 会社のサブドメイン
        """
        self._config.company_subdomain = subdomain
        self.save_config()

    # ===== Host-first 補助メソッド =====
    def _derive_from_host(self, host: str) -> dict:
        """
        host から派生して api_base_url と company_subdomain を返す。
        例: host = "seraku.newton-x.net" ->
            api_base_url = "https://seraku.newton-x.net/api"
            company_subdomain = "seraku"
        """
        host = (host or "").strip()
        if not host:
            return {"api_base_url": self._ensure_api_suffix(self._config.api_base_url), "company_subdomain": self._config.company_subdomain}
        # スキームを付与
        base = f"https://{host}"
        api_url = self._ensure_api_suffix(base)
        # サブドメインは最初のラベル
        subdomain = host.split('.')[0] if '.' in host else host
        return {"api_base_url": api_url, "company_subdomain": subdomain}

    def _ensure_api_suffix(self, url: str) -> str:
        """URL が /api で終端するように整形（スキーム+ホストのみなら /api を付与）。"""
        if not url:
            return url
        cleaned = url.rstrip('/')
        if cleaned.endswith('/api'):
            return cleaned
        # スキーム+ホストだけ、または任意パスの末尾に /api を付ける
        return cleaned + '/api'