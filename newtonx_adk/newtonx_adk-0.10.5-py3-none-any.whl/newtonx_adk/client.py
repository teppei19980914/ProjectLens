"""
NewtonX ADK メインクライアント

NewtonX APIとの通信を行うメインクライアントクラスを提供します。
"""

import json
import time
from typing import Dict, List, Optional, Any
import requests
import os
import mimetypes
from datetime import datetime, timezone

# 相対インポートを絶対インポートに変更（一時的な解決策）
try:
    from .auth import AuthManager
    from .config import ConfigManager
    from .exceptions import NewtonXError, AuthenticationError, APIError, ChatError, FileUploadError
except ImportError:
    # 相対インポートが失敗した場合は絶対インポートを試行
    from auth import AuthManager
    from config import ConfigManager
    from exceptions import NewtonXError, AuthenticationError, APIError, ChatError, FileUploadError


class NewtonXClient:
    """NewtonX APIクライアント"""
    
    def __init__(self, config_manager: Optional[ConfigManager] = None):
        """
        NewtonXクライアントの初期化
        
        Args:
            config_manager: 設定管理クラスのインスタンス（オプション）
        """
        self.config_manager = config_manager or ConfigManager()
        self.auth_manager = AuthManager(self.config_manager)
        self.config = self.config_manager.get_config()
    
    def authenticate(self) -> bool:
        """認証を実行"""
        # 内部トークンがあればMSAL認証をスキップ
        if self.auth_manager.tokens and self.auth_manager.tokens.get('newtonx_access_token'):
            try:
                # セッション確立とブートストラップ
                if not self.auth_manager.session_cookies:
                    self.auth_manager._establish_newtonx_session()
                self.auth_manager.bootstrap_session()
                return True
            except Exception:
                # スキップ失敗時は通常のMSALへフォールバック
                pass
        # 設定のauth_modeに従って取得
        token = self.auth_manager.get_access_token(mode=getattr(self.config, 'auth_mode', 'device_code'))
        return bool(token)
    
    def _make_request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
        """
        APIリクエストを実行
        
        Args:
            method: HTTPメソッド
            endpoint: APIエンドポイント
            **kwargs: リクエストパラメータ
            
        Returns:
            HTTPレスポンス
        """
        # Host-first: api_base_url を正規化して使用
        base = getattr(self.config, 'api_base_url', None) or "https://seraku.newton-x.net/api"
        if not base.rstrip('/').endswith('/api'):
            base = base.rstrip('/') + '/api'
        url = f"{base}{endpoint}"
        headers = self.auth_manager._get_headers()
        
        # ファイルアップロードの場合はContent-Typeヘッダーを削除
        if 'files' in kwargs:
            if 'Content-Type' in headers:
                del headers['Content-Type']
        
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=headers,
                timeout=self.config.timeout,
                **kwargs
            )
            
            # 認証エラー時の回復処理（Cookie破棄→再確立→再試行→再認証→再確立→再試行）
            if response.status_code == 401:
                try:
                    # 1) 既存Cookieをクリアしてからセッション再確立
                    self.auth_manager.session_cookies = {}
                    if getattr(self.auth_manager, 'tokens', None):
                        self.auth_manager.tokens.pop('session_cookies', None)
                    self.auth_manager._establish_newtonx_session()
                    self.auth_manager.bootstrap_session()
                except Exception:
                    pass

                headers = self.auth_manager._get_headers()
                response = requests.request(
                    method=method,
                    url=url,
                    headers=headers,
                    timeout=self.config.timeout,
                    **kwargs
                )

                # まだ401なら、対話/サイレント構成に従って再認証→Cookie再確立→再試行
                if response.status_code == 401:
                    print("EntraID認証を再実行します")
                    # 先にCookieをクリアして get_access_token がMSAL/AzureCLIを実行できるようにする
                    try:
                        self.auth_manager.session_cookies = {}
                        if getattr(self.auth_manager, 'tokens', None):
                            self.auth_manager.tokens.pop('session_cookies', None)
                    except Exception:
                        pass
                    _ = self.auth_manager.get_access_token(mode=getattr(self.config, 'auth_mode', 'device_code'))
                    try:
                        self.auth_manager._establish_newtonx_session()
                        self.auth_manager.bootstrap_session()
                    except Exception:
                        pass
                    headers = self.auth_manager._get_headers()
                    response = requests.request(
                        method=method,
                        url=url,
                        headers=headers,
                        timeout=self.config.timeout,
                        **kwargs
                    )
            
            return response
            
        except requests.exceptions.RequestException as e:
            raise APIError(f"API通信エラー: {e}")
    
    # ユーザー情報関連
    def get_user_info(self) -> Optional[Dict]:
        """ユーザー情報を取得"""
        try:
            # 優先: /user（OpenAPI）。サーバによっては202を返す場合があるため200/202を許容
            response = self._make_request('GET', '/user')
            if response.status_code in (200, 202):
                try:
                    return response.json()
                except Exception:
                    return None
            # フォールバック: 旧ルート
            legacy = self._make_request('GET', '/api/v1/user')
            if legacy.status_code in (200, 202):
                try:
                    return legacy.json()
                except Exception:
                    return None
            raise APIError(f"ユーザー情報取得に失敗: {response.status_code}")
        except Exception as e:
            raise APIError(f"ユーザー情報取得エラー: {e}")
    
    # アシスタント関連
    def get_assistants(self) -> List[Dict]:
        """アシスタント一覧を取得"""
        try:
            response = self._make_request('GET', '/user/assistants')
            if response.status_code == 200:
                return response.json()
            else:
                raise APIError(f"アシスタント一覧取得に失敗: {response.status_code}")
        except Exception as e:
            raise APIError(f"アシスタント一覧取得エラー: {e}")
    
    # チャット関連
    def get_chats(self, page: int = 1, page_size: int = 20, search_query: Optional[str] = None) -> List[Dict]:
        """チャット一覧を取得"""
        try:
            params = {
                'page': page,
                'page_size': page_size
            }
            if search_query:
                params['search_query'] = search_query
            
            response = self._make_request('GET', '/chats', params=params)
            if response.status_code == 200:
                return response.json()
            else:
                raise APIError(f"チャット一覧取得に失敗: {response.status_code}")
        except Exception as e:
            raise APIError(f"チャット一覧取得エラー: {e}")
    
    def create_chat(self, assistant_uid: str, title: Optional[str] = None, folder_uid: Optional[str] = None) -> Optional[str]:
        """チャットを作成（folder_uid 指定時は作成後に移動までを行う）"""
        try:
            data = {
                'assistant_uid': assistant_uid,
                'assistant_uuid': assistant_uid
            }
            
            if title:
                data['title'] = title
            
            response = self._make_request('POST', '/chats', json=data)
            if response.status_code == 201:
                chat_data = response.json()
                chat_uid = chat_data.get('uid') or chat_data.get('id') or chat_data.get('uuid')
                # フォルダ指定がある場合は、作成後に移動を実行（API仕様に従う）
                if chat_uid and folder_uid:
                    moved = self.move_chat_to_folder(str(chat_uid), str(folder_uid))
                    if not moved:
                        raise APIError("チャット作成後のフォルダ移動に失敗しました")
                return chat_uid
            else:
                raise APIError(f"チャット作成に失敗: {response.status_code}")
        except Exception as e:
            raise APIError(f"チャット作成エラー: {e}")
    
    def get_chat(self, chat_uid: str) -> Optional[Dict]:
        """チャット詳細を取得"""
        try:
            response = self._make_request('GET', f'/chats/{chat_uid}')
            if response.status_code == 200:
                return response.json()
            else:
                raise APIError(f"チャット詳細取得に失敗: {response.status_code}")
        except Exception as e:
            raise APIError(f"チャット詳細取得エラー: {e}")
    
    def send_message(
        self,
        chat_uid: str,
        message: str,
        knowledge_search: bool = False,
        web_search: bool = True,
        image_ids: Optional[List[str]] = None,
        document_ids: Optional[List[str]] = None,
        audio_file_path: Optional[str] = None,
    ) -> Optional[str]:
        """メッセージを送信"""
        try:
            # 実際のリクエスト構造に基づいてデータを構築
            data = {
                'messages': [
                    {
                        'role': 'user',
                        'content': message
                    }
                ],
                'search': web_search,  # WEB検索を有効にする場合はtrue
                'knowledge_search': knowledge_search,  # ナレッジ検索の制御
                'parent_order': 0,
                'pii_entities': [],
                'content_type': 'text/event-stream'  # SSEストリーミングを指定
            }
            
            # 相互排他: 画像IDと音声ファイルは同時指定不可
            if image_ids and audio_file_path:
                raise APIError("image_idsとaudio_file_pathは同時指定できません")

            # 画像IDが指定されている場合はmetadataに追加
            if image_ids:
                data['metadata'] = {
                    'image_ids': image_ids
                }
            
            # ドキュメントIDが指定されている場合はmetadataに追加
            if document_ids:
                if 'metadata' not in data:
                    data['metadata'] = {}
                data['metadata']['document_ids'] = document_ids
            
            # audio が指定されている場合は multipart/form-data で送信（単一ファイル）
            if audio_file_path:
                if not os.path.exists(audio_file_path):
                    raise FileUploadError(f"ファイルが存在しません: {audio_file_path}")
                filename = os.path.basename(audio_file_path)
                guessed_type = mimetypes.guess_type(filename)[0] or 'application/octet-stream'
                # 各項目を個別フィールドとして送信（messages/pii_entitiesはJSON文字列、boolは'true'/'false'）
                form_data = {
                    'messages': json.dumps(data['messages'], ensure_ascii=False),
                    'search': 1 if data.get('search') else 0,
                    'parent_order': str(data.get('parent_order', 0)),
                    'pii_entities': json.dumps(data.get('pii_entities', []), ensure_ascii=False),
                    'content_type': data.get('content_type', 'text/event-stream'),
                }
                with open(audio_file_path, 'rb') as fh:
                    files = [('audio', (filename, fh, guessed_type))]
                    response = self._make_request('POST', f'/chats/{chat_uid}', files=files, data=form_data)

            else:
                response = self._make_request('POST', f'/chats/{chat_uid}', json=data)
            if response.status_code == 200:
                # SSEストリーミングレスポンスを処理
                content_type = response.headers.get('content-type', '')
                if 'text/event-stream' in content_type:
                    return self._process_sse_response(response)
                else:
                    return response.text
            else:
                raise APIError(f"メッセージ送信に失敗: {response.status_code}")
        except Exception as e:
            raise APIError(f"メッセージ送信エラー: {e}")
    
    def send_message_with_images(
        self,
        chat_uid: str,
        message: str,
        image_file_paths: Optional[List[str]] = None,
        knowledge_search: bool = False,
        web_search: bool = True,
        document_ids: Optional[List[str]] = None,
    ) -> Optional[str]:
        """画像のアップロードとメッセージ送信を一括で行う

        1) 複数画像を /chats/{chat_uid}/images へアップロード
        2) 返却された画像UID配列を metadata.image_ids としてメッセージ送信
        """
        try:
            image_ids: Optional[List[str]] = None
            if image_file_paths:
                # PR仕様: 各画像を個別にアップロードしてID配列を作成
                image_ids = []
                for image_file_path in image_file_paths:
                    uploaded_image_id = self.upload_image(chat_uid, image_file_path)
                    if uploaded_image_id:
                        image_ids.append(uploaded_image_id)
            return self.send_message(
                chat_uid=chat_uid,
                message=message,
                knowledge_search=knowledge_search,
                web_search=web_search,
                image_ids=image_ids,
                document_ids=document_ids,
            )
        except (FileUploadError, APIError) as e:
            # 代表エラーとしてAPIErrorでラップ
            raise APIError(f"画像付きメッセージ送信エラー: {e}")

    def _process_sse_response(self, response: requests.Response) -> str:
        """
        SSEレスポンスを処理する
        
        Args:
            response: HTTPレスポンス
            
        Returns:
            処理されたレスポンス内容
        """
        full_response = ""
        
        for line in response.iter_lines(decode_unicode=True):
            if line.startswith('data: '):
                data = line[6:]  # 'data: 'を除去
                
                if data == '[DONE]':
                    break
                
                try:
                    import json
                    parsed_data = json.loads(data)
                    if parsed_data.get('type') == 'content':
                        content = parsed_data.get('content', '')
                        full_response += content
                        # リアルタイムで表示
                        print(content, end='', flush=True)
                except json.JSONDecodeError:
                    # JSONでない場合はそのまま追加
                    full_response += data
        
        print()  # 改行
        return full_response
    
    def delete_chat(self, chat_uid: str) -> bool:
        """チャットを削除"""
        try:
            response = self._make_request('DELETE', f'/chats/{chat_uid}')
            return response.status_code == 200
        except Exception as e:
            raise APIError(f"チャット削除エラー: {e}")
    
    def update_chat_title(self, chat_uid: str, title: str) -> bool:
        """チャットタイトルを更新"""
        try:
            response = self._make_request('PUT', f'/chats/{chat_uid}', json={'title': title})
            return response.status_code == 200
        except Exception as e:
            raise APIError(f"チャットタイトル更新エラー: {e}")
    
    # フォルダ関連
    def create_folder(self, name: str) -> Optional[str]:
        """フォルダを作成"""
        try:
            response = self._make_request('POST', '/folders', json={'name': name})
            if response.status_code in (200, 201):
                payload = response.json()
                folder_identifier = None
                if isinstance(payload, dict):
                    # id (int/str) or uid (str) のどちらでも受け付ける
                    if 'uid' in payload and payload['uid']:
                        folder_identifier = payload['uid']
                    elif 'id' in payload and payload['id'] is not None:
                        folder_identifier = str(payload['id'])
                    elif 'uuid' in payload and payload['uuid']:
                        folder_identifier = payload['uuid']
                return folder_identifier
            else:
                raise APIError(f"フォルダ作成に失敗: {response.status_code}")
        except Exception as e:
            raise APIError(f"フォルダ作成エラー: {e}")
    
    def get_folders(self) -> List[Dict]:
        """フォルダ一覧を取得"""
        try:
            response = self._make_request('GET', '/folders')
            if response.status_code == 200:
                return response.json()
            else:
                raise APIError(f"フォルダ一覧取得に失敗: {response.status_code}")
        except Exception as e:
            raise APIError(f"フォルダ一覧取得エラー: {e}")
    
    def move_chat_to_folder(self, chat_uid: str, folder_uid: str) -> bool:
        """チャットをフォルダに移動"""
        try:
            # OpenAPI準拠の新エンドポイント
            folder_id_value: Any = folder_uid
            try:
                folder_id_value = int(folder_uid)
            except Exception:
                pass
            response = self._make_request(
                'POST', f'/chats/{chat_uid}/folder', json={'id': chat_uid, 'folder_id': folder_id_value}
            )
            if response.status_code in (200, 201):
                return True

            # フォールバック: 旧実装の移動エンドポイント
            legacy = self._make_request('PUT', f'/chats/{chat_uid}/move', json={'folder_uid': folder_uid, 'folder_uuid': folder_uid})
            return legacy.status_code == 200
        except Exception as e:
            raise APIError(f"チャット移動エラー: {e}")
    
    def get_folder_chats(self, folder_uid: str) -> List[Dict]:
        """フォルダ内のチャット一覧を取得"""
        try:
            # OpenAPIでは /folders/{folder_id} が一覧
            primary = self._make_request('GET', f'/folders/{folder_uid}')
            if primary.status_code == 200:
                data = primary.json()
                if isinstance(data, list):
                    return data
                if isinstance(data, dict) and 'chats' in data and isinstance(data['chats'], list):
                    return data['chats']
                return []

            # フォールバック: /folders/{id}/chats 形式
            response = self._make_request('GET', f'/folders/{folder_uid}/chats')
            if response.status_code == 200:
                return response.json()
            else:
                raise APIError(f"フォルダチャット一覧取得に失敗: {response.status_code}")
        except Exception as e:
            raise APIError(f"フォルダチャット一覧取得エラー: {e}")
    
    def create_chat_in_folder(
        self,
        assistant_uid: str,
        folder_uid: str,
        title: Optional[str] = None,
        max_retries: int = 10,
        retry_interval: float = 0.5,
    ) -> Optional[str]:
        """フォルダ内にチャットを作成（作成→移動を内包）

        一部環境ではフォルダ作成直後に移動APIが失敗するまでの伝搬遅延があるため、
        リトライでフォルダ移動を安定化させる。
        """
        try:
            chat_uid = self.create_chat(assistant_uid=assistant_uid, title=title)
            if not chat_uid:
                return None

            # フォルダ移動をリトライ
            for _ in range(max_retries):
                try:
                    if self.move_chat_to_folder(chat_uid, folder_uid):
                        return chat_uid
                except APIError:
                    # 続行してリトライ
                    pass
                time.sleep(retry_interval)

            # 最終確認で失敗扱い
            return None
        except Exception as e:
            raise APIError(f"フォルダ内チャット作成エラー: {e}")

    def create_chat_in_folder_by_name(
        self,
        assistant_uid: str,
        folder_name: str,
        title: Optional[str] = None,
        create_if_missing: bool = True,
        readiness_max_retries: int = 10,
        readiness_retry_interval: float = 0.5,
        move_max_retries: int = 10,
        move_retry_interval: float = 0.5,
    ) -> Optional[str]:
        """フォルダ名を指定してチャットを作成（存在すれば利用、なければ作成）

        仕様:
        - フォルダ名で検索し、存在しなければ作成。
        - フォルダ作成直後は伝搬待ちのため、一覧や参照が可能になるまで待機。
        - チャットを先に作成し、その後にフォルダへ移動（リトライ付き）。
        """
        try:
            # 1) 既存フォルダ検索
            folders = self.get_folders()
            target_folder_uid: Optional[str] = None
            for f in folders:
                if f.get('name') == folder_name:
                    target_folder_uid = f.get('uid') or f.get('id') or f.get('uuid')
                    break

            # 2) なければ作成
            if not target_folder_uid:
                if not create_if_missing:
                    raise APIError(f"フォルダが見つかりません: {folder_name}")
                target_folder_uid = self.create_folder(folder_name)
                if not target_folder_uid:
                    raise APIError("フォルダ作成に失敗しました")

                # 2-1) 作成直後の伝搬待ち（一覧に出る、もしくは参照が通るまで）
                for _ in range(readiness_max_retries):
                    try:
                        folders = self.get_folders()
                        if any((x.get('uid') or x.get('id') or x.get('uuid')) == target_folder_uid for x in folders):
                            break
                    except Exception:
                        pass
                    time.sleep(readiness_retry_interval)

            # 3) チャットを作成→移動（内部で移動リトライ）
            return self.create_chat_in_folder(
                assistant_uid=assistant_uid,
                folder_uid=str(target_folder_uid),
                title=title,
                max_retries=move_max_retries,
                retry_interval=move_retry_interval,
            )
        except Exception as e:
            raise APIError(f"フォルダ名指定チャット作成エラー: {e}")
    
    # ファイルアップロード関連
    def upload_image(self, chat_uid: str, file_path: str, file_name: Optional[str] = None) -> Optional[str]:
        """画像をアップロード"""
        try:
            if not file_name:
                file_name = os.path.basename(file_path)
            
            # ファイル存在チェック
            if not os.path.exists(file_path):
                raise FileUploadError(f"ファイルが存在しません: {file_path}")
            
            # ファイルサイズチェック
            file_size = os.path.getsize(file_path)
            if file_size == 0:
                raise FileUploadError("ファイルが空です")
            
            # ファイルサイズ制限チェック（10MB）
            max_size = 10 * 1024 * 1024
            if file_size > max_size:
                raise FileUploadError(f"ファイルサイズが大きすぎます: {file_size} bytes (制限: {max_size} bytes)")
            
            with open(file_path, 'rb') as f:
                guessed_type = mimetypes.guess_type(file_name)[0] or 'application/octet-stream'
                files = {'images[]': (file_name, f, guessed_type)}
                response = self._make_request('POST', f'/chats/{chat_uid}/images', files=files)
            
            # 200（OK）と201（Created）の両方を成功として扱う
            if response.status_code in [200, 201]:
                result = response.json()
                # APIレスポンス形式に応じてimage_idを取得
                if 'uids' in result and result['uids']:
                    image_id = result['uids'][0]
                elif 'image_id' in result:
                    image_id = result['image_id']
                elif 'uuid' in result and result['uuids']:
                    image_id = result['uuids'][0]
                else:
                    image_id = None
                return image_id
            else:
                raise FileUploadError(f"画像アップロードに失敗: {response.status_code} - {response.text}")
        except Exception as e:
            raise FileUploadError(f"画像アップロードエラー: {e}")
    
    def upload_images(self, chat_uid: str, file_paths: List[str]) -> List[str]:
        """複数画像をそのままアップロードし、画像UID配列を返す

        API仕様に従い、フィールド名 `images[]` を複数個付けて送信する。
        成功時は `uids: [string]` または `id: string` を解釈して返す。
        """
        try:
            if not file_paths:
                raise FileUploadError("ファイルパスのリストが空です")

            # 事前バリデーション（存在・サイズ）
            max_size = 10 * 1024 * 1024
            validated_files: List[str] = []
            for path in file_paths:
                if not os.path.exists(path):
                    raise FileUploadError(f"ファイルが存在しません: {path}")
                size = os.path.getsize(path)
                if size == 0:
                    raise FileUploadError(f"ファイルが空です: {path}")
                if size > max_size:
                    raise FileUploadError(f"ファイルサイズが大きすぎます: {size} bytes (制限: {max_size} bytes) - {path}")
                validated_files.append(path)

            # 複数ファイルを同一フィールド名で送信
            file_handles: List[object] = []
            try:
                files = []
                for path in validated_files:
                    fh = open(path, 'rb')
                    file_handles.append(fh)
                    filename = os.path.basename(path)
                    guessed_type = mimetypes.guess_type(filename)[0] or 'application/octet-stream'
                    files.append(('images[]', (filename, fh, guessed_type)))
                response = self._make_request('POST', f'/chats/{chat_uid}/images', files=files)
            finally:
                for fh in file_handles:
                    try:
                        fh.close()
                    except Exception:
                        pass

            if response.status_code in [200, 201]:
                result = response.json()

                filtered = None
                error_message = "レスポンス形式不明"

                # レスポンス形式チェック
                if not isinstance(result, dict):
                    raise FileUploadError(f"画像UIDが取得できませんでした（{error_message}）")

                # OpenAPIでは uids: [string] または id: string
                if 'uids' in result and isinstance(result['uids'], list):
                    error_message = "uidsが空"
                    filtered = [uid for uid in result['uids'] if isinstance(uid, str)]
                elif 'uuids' in result and isinstance(result['uuids'], list):
                    error_message = "uuidsが空"
                    filtered = [uuid for uuid in result['uuids'] if isinstance(uuid, str)]
                elif 'id' in result and isinstance(result['id'], str):
                    error_message = "idが空"
                    filtered = [result['id']]
                else:
                    raise FileUploadError(f"画像UIDが取得できませんでした（{error_message}）")

                # フィルタリング後のUID配列が存在する場合は返却
                if not filtered:
                    raise FileUploadError(f"画像UIDが取得できませんでした（{error_message}）")

                return filtered

            else:
                raise FileUploadError(f"画像アップロードに失敗: {response.status_code} - {response.text}")
        except Exception as e:
            raise FileUploadError(f"画像アップロードエラー: {e}")

    def upload_document(self, chat_uid: str, file_path: str, file_name: Optional[str] = None) -> bool:
        """ドキュメントをアップロード"""
        try:
            if not file_name:
                file_name = os.path.basename(file_path)
            
            # ファイル存在チェック
            if not os.path.exists(file_path):
                raise FileUploadError(f"ファイルが存在しません: {file_path}")
            
            # ファイルサイズチェック
            file_size = os.path.getsize(file_path)
            if file_size == 0:
                raise FileUploadError("ファイルが空です")
            
            # ファイルサイズ制限チェック（10MB）
            max_size = 10 * 1024 * 1024
            if file_size > max_size:
                raise FileUploadError(f"ファイルサイズが大きすぎます: {file_size} bytes (制限: {max_size} bytes)")

            guessed_type = mimetypes.guess_type(file_name)[0] or 'application/octet-stream'
            with open(file_path, 'rb') as f:
                files = {'file': (file_name, f, guessed_type)}
                # 一部環境で updated_at が必須。UTC ISO8601で付与
                # 形式: Y-m-dTH:i:s.vZ （例: 2025-10-01T12:34:56.789Z）
                now_utc = datetime.now(timezone.utc)
                millis = f"{int(now_utc.microsecond / 1000):03d}"
                updated_at_str = now_utc.strftime('%Y-%m-%dT%H:%M:%S.') + millis + 'Z'
                form_data = {
                    'updated_at': updated_at_str
                }
                response = self._make_request('POST', f'/chats/{chat_uid}/document', files=files,  data=form_data)
            
            # 200（OK）と201（Created）の両方を成功として扱う
            if response.status_code in [200, 201]:
                # NewtonX APIはファイルアップロード時にuidを返さない場合がある
                # 代わりにチャット内でファイルを自動認識する仕組み
                return True
            else:
                raise FileUploadError(f"ドキュメントアップロードに失敗: {response.status_code} - {response.text}")
        except Exception as e:
            raise FileUploadError(f"ドキュメントアップロードエラー: {e}")
    
    # ナレッジ（アシスタント紐づけRAG）関連
    def add_assistant_knowledge(self, assistant_uid: str, file_path: str, file_name: Optional[str] = None) -> Optional[str]:
        """アシスタントにナレッジファイルを登録（アップロード）

        対応形式: docx, xls, xlsx, pptx, pdf, txt（16MB以下）

        Returns:
            追加されたナレッジファイルのID（取得できる場合）。取得不可時はNone。
        """
        try:
            if not file_name:
                file_name = os.path.basename(file_path)

            # 対応拡張子とサイズチェック（16MB）
            allowed_exts = {'.docx', '.xls', '.xlsx', '.pptx', '.pdf', '.txt'}
            ext = os.path.splitext(file_name)[1].lower()
            if ext not in allowed_exts:
                raise FileUploadError(f"未対応のファイル形式です: {ext}")

            if not os.path.exists(file_path):
                raise FileUploadError(f"ファイルが存在しません: {file_path}")

            file_size = os.path.getsize(file_path)
            max_size = 16 * 1024 * 1024
            if file_size == 0:
                raise FileUploadError("ファイルが空です")
            if file_size > max_size:
                raise FileUploadError(f"ファイルサイズが大きすぎます: {file_size} bytes (制限: {max_size} bytes)")

            # Content-Type を推定
            guessed_type = mimetypes.guess_type(file_name)[0] or 'application/octet-stream'
            with open(file_path, 'rb') as f:
                files = {'file': (file_name, f, guessed_type)}
                # 一部環境で updated_at が必須。UTC ISO8601で付与
                # 形式: Y-m-dTH:i:s.vZ （例: 2025-10-01T12:34:56.789Z）
                now_utc = datetime.now(timezone.utc)
                millis = f"{int(now_utc.microsecond / 1000):03d}"
                updated_at_str = now_utc.strftime('%Y-%m-%dT%H:%M:%S.') + millis + 'Z'
                form_data = {
                    'updated_at': updated_at_str
                }
                response = self._make_request('POST', f'/assistants/{assistant_uid}/files', files=files, data=form_data)

            if response.status_code in (200, 201):
                # 返却JSONから ID を推測して取得（uid, id, file_uidなど一般的なキーを許容）
                try:
                    payload = response.json()
                    if isinstance(payload, dict):
                        for key in ('uid', 'uuid', 'id', 'file_uid', 'file_uuid', 'file_id'):
                            if key in payload and payload[key]:
                                return str(payload[key])
                except Exception:
                    pass
                return None
            raise FileUploadError(f"ナレッジ登録に失敗: {response.status_code} - {getattr(response, 'text', '')}")
        except Exception as e:
            raise FileUploadError(f"ナレッジ登録エラー: {e}")

    def delete_assistant_knowledge(self, assistant_uid: str, file_uid: str) -> bool:
        """アシスタントからナレッジファイルを削除

        成功時 True を返す。DELETE /assistants/{assistant_uid}/files に
        JSON ボディ {"file_uids": [file_uid]} を送るWEB版仕様に準拠。
        """
        try:
            response = self._make_request(
                'DELETE', f'/assistants/{assistant_uid}/files', json={'file_uids': [file_uid], 'file_uuids': [file_uid]}
            )
            if response.status_code in (200, 202, 204):
                return True
            try:
                payload = response.json()
                if isinstance(payload, dict) and payload.get('success') is True:
                    return True
            except Exception:
                pass
            return False
        except Exception as e:
            raise APIError(f"ナレッジ削除エラー: {e}")
    
    def get_assistant_knowledge(self, assistant_uid: str, page: int = 1, page_size: int = 100) -> List[Dict[str, Any]]:
        """アシスタントに登録されているナレッジ一覧を取得

        WEB版準拠: GET /assistants/{assistant_uid}/files
        返却形式は配列、または { files: [...] } のいずれかに対応する。
        """
        try:
            resp = self._make_request('GET', f'/assistants/{assistant_uid}/files', params={'page': page, 'page_size': page_size})
            if resp.status_code not in (200, 202):
                raise APIError(f"ナレッジ一覧取得に失敗: {resp.status_code}")
            payload = resp.json()
            if isinstance(payload, list):
                return payload
            if isinstance(payload, dict):
                files = payload.get('files')
                if isinstance(files, list):
                    return files
                data_items = payload.get('data')
                if isinstance(data_items, list):
                    return data_items
            return []
        except Exception as e:
            raise APIError(f"ナレッジ一覧取得エラー: {e}")
    
    # システム情報関連
    def get_model_status(self) -> Dict[str, bool]:
        """モデルステータスを取得"""
        try:
            # 優先: /models/status（OpenAPI）。サーバ差異に備えてフォールバック
            response = self._make_request('GET', '/models/status')
            if response.status_code in (200, 202):
                return response.json()
            # フォールバック: 旧ルート /system/models
            legacy = self._make_request('GET', '/system/models')
            if legacy.status_code in (200, 202):
                return legacy.json()
            # 最後のフォールバック: 未提供環境では空結果を返して継続
            return {}
        except Exception as e:
            raise APIError(f"モデルステータス取得エラー: {e}")
    
    def get_company_info(self) -> Optional[Dict]:
        """会社情報を取得"""
        try:
            response = self._make_request('GET', '/company')
            if response.status_code == 200:
                return response.json()
            else:
                raise APIError(f"会社情報取得に失敗: {response.status_code}")
        except Exception as e:
            raise APIError(f"会社情報取得エラー: {e}") 