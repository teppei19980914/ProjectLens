# NewtonX エージェント開発キット (NewtonX ADK)

**NewtonX（ニュートンX）のAIアシスタントと簡単にやり取りできるPythonライブラリです**

このライブラリを使うと、PythonプログラムからNewtonXのAIアシスタントとチャットしたり、ファイルを送ったりできます。

## 🚀 まずは使ってみよう

### ステップ1: ライブラリをインストール

```bash
pip install newtonx-adk
```

### ステップ2: 設定を簡単に行う

**方法1: セットアップツールを使用（推奨）**

```bash
# オブジェクトID認証の設定を対話的に行う
python tools/setup_auth.py
```

**方法2: コマンドで設定**

```bash
# ホスト名を設定
newtonx-config set --host "seraku.newton-x.net"

# 会社のID情報を設定（オブジェクトID認証用）
newtonx-config set \
  --tenant-id "あなたのテナントID" \
  --client-id "あなたのクライアントID" \
  --object-id "あなたのオブジェクトID" \
  --use-object-id-auth true
```

**方法3: もしコマンドが動かない場合**

```bash
# この方法でも同じことができます
python -m newtonx_adk.config_cli set --host "seraku.newton-x.net"
python -m newtonx_adk.config_cli set --tenant-id "あなたのテナントID" --client-id "あなたのクライアントID" --object-id "あなたのオブジェクトID" --use-object-id-auth true
```

### ステップ3: 実際に使ってみる

```python
from newtonx_adk import NewtonXClient, ConfigManager

# 設定を読み込んでクライアントを作成
config = ConfigManager()
client = NewtonXClient(config)

# 認証（オブジェクトID認証で1段階で完了）
if client.authenticate():
    print("✅ 認証成功！")
    
    # アシスタント一覧を取得
    assistants = client.get_assistants()
    print(f"利用可能なアシスタント: {len(assistants)}個")
    
    # チャットを開始
    chat_uid = client.create_chat(
        assistant_uid=assistants[0]['uid'],  # 最初のアシスタントを選択
        title="テストチャット"
    )
    
    # メッセージを送信
    response = client.send_message(
        chat_uid=chat_uid,
        message="こんにちは！"
    )
    
    print(f"アシスタントの返事: {response}")
else:
    print("❌ 認証に失敗しました")
```

## 📋 できること

### 🤖 AIアシスタントとのチャット
- 複数のアシスタントから選んでチャット
- ウェブ検索やナレッジ検索を有効にできる
- チャットのタイトルを変更可能

### 📁 ファイルの送信
- 画像ファイル（JPG、PNG、GIFなど）
- ドキュメント（PDF、Word、テキストなど）
- ファイルサイズは10MBまで

### 🔐 安全な認証
- オブジェクトID認証（1段階で完了）
- ブラウザでの安全なログイン
- 自動でトークンを更新
- 設定情報を安全に保存

## 🛠️ よくある使い方

### 1. アシスタント一覧を見る

```python
assistants = client.get_assistants()
for assistant in assistants:
    print(f"名前: {assistant['name']}")
    print(f"説明: {assistant.get('description', '説明なし')}")
    print("---")
```

### 2. チャットを始める

```python
# チャットを作成
chat_uid = client.create_chat(
    assistant_uid="アシスタントのID",
    title="私のチャット"
)

# メッセージを送る
response = client.send_message(
    chat_uid=chat_uid,
    message="今日の天気はどうですか？",
    web_search=True  # ウェブ検索を有効にする
)
```

### 3. ファイルを送る

```python
# 画像を送る
image_id = client.upload_image(
    chat_uid=chat_uid,
    file_path="写真.jpg"
)

# ドキュメントを送る
success = client.upload_document(
    chat_uid=chat_uid,
    file_path="資料.pdf"
)
```

## ❗ 困ったときは

### コマンドが動かない場合

```bash
# この方法で代用できます
python -m newtonx_adk.config_cli --help
python -m newtonx_adk.config_cli show
```

### 認証でエラーが出る場合

1. **オブジェクトID認証が有効になっていない**: `newtonx-config set --use-object-id-auth true` を実行してください
2. **オブジェクトIDが設定されていない**: `python tools/setup_auth.py` で設定してください
3. **ブラウザが開かない**: 手動で認証URLを開いてください
4. **「無効なクライアント」エラー**: オブジェクトID認証を使用してください
5. **404エラー**: ホスト名に `/api` が付いているか確認してください

### 設定を確認する

```bash
# 現在の設定を見る
newtonx-config show

# 設定をリセットする
newtonx-config reset
```

## 📚 もっと詳しく知りたい方へ

- **APIリファレンス**: [API_REFERENCE.md](../../docs/adk/API_REFERENCE.md)
- **使用ガイド**: [USAGE_GUIDE.md](../../docs/adk/USAGE_GUIDE.md)
- **実装例**: [adk_examples](../../adk_examples/) フォルダ

## 🔧 開発者向け情報

### エラーハンドリング

```python
from newtonx_adk import (
    NewtonXError,           # 基本エラー
    AuthenticationError,    # 認証エラー
    APIError,              # APIエラー
    ConfigurationError,    # 設定エラー
    FileUploadError,       # ファイルアップロードエラー
    ChatError              # チャットエラー
)

try:
    client.get_assistants()
except AuthenticationError:
    print("認証が必要です")
except APIError as e:
    print(f"APIエラー: {e}")
```

### 環境変数での設定

```bash
export NEWTONX_CLIENT_ID="あなたのクライアントID"
export NEWTONX_TENANT_ID="あなたのテナントID"
export NEWTONX_API_BASE_URL="https://seraku.newton-x.net/api"
```

## 📄 ライセンス

MIT License

## 🆘 サポート

- 問題が起きたら、まずは `newtonx-config show` で設定を確認してください
- それでも解決しない場合は、エラーメッセージと一緒にご連絡ください

---

**NewtonX ADKで、AIアシスタントとの新しい体験を始めましょう！** 🎉