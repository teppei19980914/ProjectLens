"""
NewtonX ADK 例外クラス

ADKで使用する例外クラスを定義します。
"""


class NewtonXError(Exception):
    """NewtonX ADKの基本例外クラス"""
    pass


class AuthenticationError(NewtonXError):
    """認証関連の例外"""
    pass


class APIError(NewtonXError):
    """API通信関連の例外"""
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class ConfigurationError(NewtonXError):
    """設定関連の例外"""
    pass


class FileUploadError(NewtonXError):
    """ファイルアップロード関連の例外"""
    pass


class ChatError(NewtonXError):
    """チャット関連の例外"""
    pass 