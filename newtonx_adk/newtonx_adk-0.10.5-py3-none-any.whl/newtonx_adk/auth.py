"""
NewtonX ADK 認証管理

NewtonX APIの認証を管理するクラスを提供します。
ブラウザベースの認証フローを実装します。
"""

import json
import time
import re
from pathlib import Path
from typing import Dict, Optional

import requests
from msal import PublicClientApplication, SerializableTokenCache
import base64
import hashlib
import os
import secrets
import threading
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler

try:
    from .config import ConfigManager
    from .exceptions import AuthenticationError, APIError
except ImportError:
    from config import ConfigManager
    from exceptions import AuthenticationError, APIError


class AuthManager:
    """認証管理クラス"""
    
    def __init__(self, config_manager: ConfigManager):
        """
        認証管理クラスの初期化
        
        Args:
            config_manager: 設定管理クラスのインスタンス
        """
        self.config_manager = config_manager
        self.config = config_manager.get_config()
        
        # トークン情報
        self.tokens = self._load_tokens()
        
        # MSALアプリケーション
        self.msal_app = None
        
        # セッションクッキー
        self.session_cookies = {}
        
        # トークンファイルパス
        self.token_file_path = Path(self.config.token_file).expanduser()
    
    def _build_authority(self) -> str:
        """MSALのオーソリティURLを構築する"""
        if getattr(self.config, 'authority', None):
            return self.config.authority
        return f"https://login.microsoftonline.com/{self.config.tenant_id}"

    def _init_msal_app(self):
        """MSAL PublicClientApplication を初期化する（公開クライアント）"""
        if not self.msal_app:
            # トークンキャッシュのセットアップ
            self._msal_cache = SerializableTokenCache()
            token_parent = Path(self.config.token_file).expanduser().parent
            token_parent.mkdir(parents=True, exist_ok=True)
            self._msal_cache_path = token_parent / 'msal_cache.bin'
            if self._msal_cache_path.exists():
                try:
                    self._msal_cache.deserialize(self._msal_cache_path.read_text(encoding='utf-8'))
                except Exception:
                    # 破損時は新規キャッシュとして扱う
                    self._msal_cache = SerializableTokenCache()

            self.msal_app = PublicClientApplication(
                client_id=self.config.client_id,
                authority=self._build_authority(),
                token_cache=self._msal_cache,
            )

    def _persist_cache(self) -> None:
        """MSALトークンキャッシュを永続化"""
        try:
            if getattr(self, '_msal_cache', None) and self._msal_cache.has_state_changed:
                self._msal_cache_path.write_text(self._msal_cache.serialize(), encoding='utf-8')
        except Exception:
            pass
    

    def _choose_scopes(self, scopes: Optional[list]) -> list:
        # リフレッシュ可能にするため offline_access/openid/profile を必ず付与
        base: list[str]
        if scopes:
            base = list(scopes)
        else:
            cfg_scopes = getattr(self.config, 'graph_scopes', None)
            base = list(cfg_scopes) if cfg_scopes else ["User.Read"]
        extras = ["offline_access", "openid", "profile"]
        for e in extras:
            if e not in base:
                base.append(e)
        return base

    def _auth_mode(self, mode: Optional[str]) -> str:
        """認証モードを決定する

        優先順位: 引数 > 設定 > 既定
        サポート: 'azure_cli' | 'silent' | 'interactive' | 'none' | 'device_code'(互換: interactive)
        """
        if isinstance(mode, str) and mode.strip():
            selected = mode.strip().lower()
        else:
            cfg_mode = getattr(self.config, 'auth_mode', '') or ''
            selected = str(cfg_mode).strip().lower()
        if selected in ('azure_cli', 'silent', 'interactive', 'none'):
            return selected
        if selected == 'device_code':
            return 'interactive'
        # 既定は対話よりも静的手段を優先
        return 'silent'

    def _save_access_token(self, result: Dict) -> Optional[str]:
        access_token = result.get('access_token') if isinstance(result, dict) else None
        if not access_token:
            return None
        expires_in = result.get('expires_in', 3600)
        # 既存の newtonx_access_token や session_cookies を保持したまま更新
        if not self.tokens or not isinstance(self.tokens, dict):
            self.tokens = {}
        self.tokens['access_token'] = access_token
        self.tokens['refresh_token'] = result.get('refresh_token', '')
        self.tokens['expires_at'] = time.time() + expires_in
        self.tokens['token_type'] = result.get('token_type', 'Bearer')
        self._save_tokens()
        self._persist_cache()
        return access_token

    def _acquire_token(self, scopes: list, mode: Optional[str] = None) -> Optional[str]:
        selected = self._auth_mode(mode)

        # Azure CLI 経由
        if selected == 'azure_cli':
            token = self._acquire_token_via_azure_cli(scopes)
            if token:
                return token
            # フォールバックでサイレントも試す
            selected = 'silent'

        # MSAL: サイレント
        self._init_msal_app()
        try:
            accounts = self.msal_app.get_accounts()
            if accounts:
                result = self.msal_app.acquire_token_silent(scopes=scopes, account=accounts[0])
                if result and 'access_token' in result:
                    return self._save_access_token(result)
        except Exception:
            pass

        # MSAL: 対話
        if selected == 'interactive':
            try:
                print("=== PKCE認証（ブラウザ）===")
                return self._interactive_pkce_with_local_server(scopes)
            except Exception as e:
                print(f"PKCE interactive exception: {e}")
                return None

        # 'silent' または 'none' の場合はここで終了
        return None

    def _acquire_token_via_azure_cli(self, scopes: list) -> Optional[str]:
        """Azure CLI からアクセストークンを取得する（Brokered Auth）

        事前に `az login` 済みであること。失敗時は None。
        優先的に Microsoft Graph のトークンを要求する。
        """
        try:
            import json as _json
            import shutil
            import subprocess
            # az が見つからない場合はスキップ
            if not shutil.which('az'):
                return None

            # --resource-type ms-graph でGraphトークンを取得
            cmd = ['az', 'account', 'get-access-token', '--resource-type', 'ms-graph', '--output', 'json']
            completed = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
            if completed.returncode != 0:
                return None
            data = _json.loads(completed.stdout or '{}')
            access_token = data.get('accessToken') or data.get('access_token')
            expires_on = data.get('expiresOn') or data.get('expires_on')
            if not access_token:
                return None
            # 保存（期限は参考値として保持）
            result = {'access_token': access_token, 'expires_in': 3600}
            return self._save_access_token(result)
        except Exception:
            return None

    # ===== PKCE + ローカルHTTPコールバック 実装 =====
    def _generate_pkce_pair(self) -> tuple[str, str]:
        verifier = base64.urlsafe_b64encode(os.urandom(40)).rstrip(b'=').decode('ascii')
        digest = hashlib.sha256(verifier.encode('ascii')).digest()
        challenge = base64.urlsafe_b64encode(digest).rstrip(b'=').decode('ascii')
        return verifier, challenge

    def _build_authorize_url(self, scopes: list, redirect_uri: str, code_challenge: str, state: str) -> str:
        tenant = self.config.tenant_id or 'common'
        auth_endpoint = f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize"
        query = {
            'client_id': self.config.client_id,
            'response_type': 'code',
            'redirect_uri': redirect_uri,
            'response_mode': 'query',
            'scope': ' '.join(scopes),
            'code_challenge': code_challenge,
            'code_challenge_method': 'S256',
            'state': state,
            'prompt': 'select_account'
        }
        encoded_query = urllib.parse.urlencode(query, safe='~')
        return f"{auth_endpoint}?{encoded_query}"

    def _exchange_code_for_token(self, code: str, redirect_uri: str, code_verifier: str, scopes: list) -> Optional[str]:
        tenant = self.config.tenant_id or 'common'
        token_endpoint = f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
        data = {
            'grant_type': 'authorization_code',
            'client_id': self.config.client_id,
            'code': code,
            'redirect_uri': redirect_uri,
            'code_verifier': code_verifier,
            'scope': ' '.join(scopes),
        }
        resp = requests.post(token_endpoint, data=data, timeout=15)
        if resp.status_code == 200:
            return self._save_access_token(resp.json())
        print(f"Token exchange failed: {resp.status_code} - {resp.text}")
        return None

    def _interactive_pkce_with_local_server(self, scopes: list) -> Optional[str]:
        # ループバックURI（デフォルト）
        redirect_uri = getattr(self.config, 'redirect_uri', 'http://localhost:8400')
        parsed = urllib.parse.urlparse(redirect_uri)
        host = parsed.hostname or 'localhost'
        port = parsed.port or 8400
        path = parsed.path or '/'

        code_verifier, code_challenge = self._generate_pkce_pair()
        state = secrets.token_urlsafe(16)

        result_holder: Dict[str, Optional[str]] = {'code': None, 'state': None}
        httpd = None
        thread = None

        class CallbackHandler(BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                parsed_q = urllib.parse.urlparse(self.path)
                if parsed_q.path != path:
                    self.send_response(404)
                    self.end_headers()
                    return
                qs = urllib.parse.parse_qs(parsed_q.query)
                code = qs.get('code', [None])[0]
                st = qs.get('state', [None])[0]
                result_holder['code'] = code
                result_holder['state'] = st
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.end_headers()
                html = (
                    "<!DOCTYPE html><html lang=\"ja\"><head><meta charset=\"utf-8\">"
                    "<title>認証が完了しました</title></head><body>"
                    "<h1>認証が完了しました</h1>"
                    "<p>このウィンドウは閉じてもかまいません。</p>"
                    "<script>setTimeout(() => window.close(), 1500);</script>"
                    "</body></html>"
                )
                self.wfile.write(html.encode('utf-8'))

            def log_message(self, fmt, *args):
                return

        # サーバ起動（ポートが使用中なら次へ）
        max_retries = 5
        for _ in range(max_retries):
            try:
                httpd = HTTPServer((host, port), CallbackHandler)
                thread = threading.Thread(target=httpd.serve_forever, daemon=True)
                thread.start()
                break
            except OSError:
                port += 1
                redirect_uri = f"http://{host}:{port}{path}"

        try:
            url = self._build_authorize_url(scopes, redirect_uri, code_challenge, state)
            print("ブラウザで認証ページを開いています...")
            print(f"認証URL: {url}")
            import webbrowser
            webbrowser.open(url)

            # 待機
            import time as _time
            timeout_seconds = getattr(self.config, 'auth_timeout', 300)
            deadline = _time.time() + timeout_seconds
            while _time.time() < deadline:
                if result_holder['code'] and result_holder['state'] == state:
                    break
                _time.sleep(0.3)

            code = result_holder['code']
            if not code:
                print("認可コードの取得に失敗しました（タイムアウト）")
                return None
            print("認可コードを取得しました。トークン交換中...")
            return self._exchange_code_for_token(code, redirect_uri, code_verifier, scopes)
        finally:
            if httpd:
                try:
                    httpd.shutdown()
                    if thread and thread.is_alive():
                        thread.join(timeout=2)
                except Exception:
                    pass
    
    def _load_tokens(self) -> Dict:
        """
        トークンファイルを読み込む
        
        Returns:
            トークン情報の辞書
        """
        token_file_path = Path(self.config.token_file).expanduser()
        if token_file_path.exists():
            try:
                with open(token_file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    
                    # セッションクッキーを読み込む
                    if 'session_cookies' in data:
                        self.session_cookies = data['session_cookies']
                        # self.tokensにもsession_cookiesを含める（認証ヘッダー生成のため）
                        self.tokens = data.copy()
                    else:
                        # session_cookiesがない場合は、MSALトークンのみ
                        self.tokens = {k: v for k, v in data.items() if k != 'session_cookies'}
                    
                    return data
            except Exception as e:
                print(f"トークンファイル読み込みエラー: {e}")
        return {}
    
    def _save_tokens(self) -> None:
        """トークンファイルを保存する"""
        token_file_path = Path(self.config.token_file).expanduser()
        token_file_path.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            # トークンとセッションクッキーを保存（分離して保存）
            save_data = self.tokens.copy()
            if hasattr(self, 'session_cookies') and self.session_cookies:
                save_data['session_cookies'] = self.session_cookies
            
            with open(token_file_path, 'w', encoding='utf-8') as f:
                json.dump(save_data, f, indent=2)
        except Exception as e:
            print(f"トークンファイル保存エラー: {e}")
    
    def is_authenticated(self) -> bool:
        """
        認証状態を確認する
        
        Returns:
            認証済みの場合True
        """
        # PAT（Personal Access Token）が設定されている場合はそれだけで認証済み
        try:
            pat = getattr(self.config, 'personal_access_token', '') or ''
            if isinstance(pat, str) and pat.strip():
                return True
        except Exception:
            pass
        # NewtonX内部トークンがある場合は認証済みとみなす
        if self.tokens and self.tokens.get('newtonx_access_token'):
            return True
        # セッションクッキーがある場合も認証済みとみなす
        if hasattr(self, 'session_cookies') and self.session_cookies:
            return True
        # トークンベースの認証（後方互換性のため、MSALアクセストークン）
        if not self.tokens:
            return False
        
        # トークンの有効期限をチェック
        current_time = time.time()
        if 'expires_at' in self.tokens:
            if current_time >= self.tokens['expires_at']:
                return False
        
        return True
    
    def authenticate(self) -> bool:
        """
        ブラウザベースの認証を実行する
        
        Returns:
            認証成功の場合True
        """
        try:
            # NewtonXの認証フローを使用
            auth_url = self._generate_newtonx_auth_url()
            print(f"認証URL: {auth_url}")
            print("ブラウザで上記URLにアクセスして認証を完了してください。")
            print("認証が完了すると、NewtonXのWEBアプリケーションに遷移します。")
            print()
            print("認証が完了したら、Enterキーを押してください: ", end="")
            input()
            
            # 認証後のトークン取得を試行
            print("認証後のトークン取得を試行中...")
            
            # NewtonXのAPIからセッション情報を取得
            session_info = self._get_newtonx_token()
            if session_info:
                # セッションクッキーが保存されている場合は認証成功
                if hasattr(self, 'session_cookies') and self.session_cookies:
                    print("認証が完了しました。")
                    return True
                else:
                    print("セッション情報の取得に失敗しました。")
                    return False
            else:
                print("セッション情報の取得に失敗しました。")
                return False
            
        except Exception as e:
            print(f"認証エラー: {e}")
            return False
    
    def authenticate_auto(self) -> bool:
        """
        自動認証を実行する（ユーザーインタラクションなし）
        
        Returns:
            認証成功の場合True
        """
        try:
            print("自動認証を開始します...")
            
            # セッションを作成してクッキーを管理
            session = requests.Session()
            session.headers.update({
                'User-Agent': 'NewtonX-ADK/0.10.5',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            })
            
            # 認証URLにアクセスしてセッションを確立（Host-first対応）
            web_base_url = self.config.api_base_url.rsplit('/api', 1)[0] if getattr(self.config, 'api_base_url', None) else "https://seraku.newton-x.net"
            subdomain = self.config.company_subdomain or (self.config.host.split('.')[0] if getattr(self.config, 'host', None) else "")
            auth_url = f"{web_base_url}/account/redirectadlogin" + (f"?subdomain={subdomain}" if subdomain else "")
            
            print(f"認証URLにアクセス: {auth_url}")
            response = session.get(auth_url, allow_redirects=False, timeout=10)
            print(f"認証URLアクセス応答: {response.status_code}")
            
            # リダイレクト先にアクセスしてセッションを確立
            if response.status_code == 302:
                redirect_url = response.headers.get('Location')
                print(f"リダイレクト先: {redirect_url}")
                
                # リダイレクト先にアクセス
                redirect_response = session.get(redirect_url, timeout=10)
                print(f"リダイレクト先応答: {redirect_response.status_code}")
            
            # セッションクッキーを保存
            if session.cookies:
                print(f"セッションクッキー数: {len(session.cookies)}")
                for cookie_name in session.cookies.keys():
                    print(f"   クッキー: {cookie_name}")
                
                # セッション情報を保存
                self.session_cookies = dict(session.cookies)
                
                # アクセストークンを取得する試行
                access_token = self._get_access_token_from_session(session)
                if access_token:
                    # アクセストークンを保存
                    self.tokens = {
                        'access_token': access_token,
                        'refresh_token': '',
                        'expires_at': time.time() + 3600,  # 1時間後
                        'token_type': 'Bearer'
                    }
                    self._save_tokens()
                    print("アクセストークンを取得しました。")
                    return True
                
                print("アクセストークンの取得に失敗しました。")
                return False
            else:
                print("セッションクッキーが見つかりません")
                return False
                
        except Exception as e:
            print(f"自動認証エラー: {e}")
            return False
    
    def _generate_newtonx_auth_url(self) -> str:
        """
        NewtonXの認証URLを生成する
        
        Returns:
            NewtonXの認証URL
        """
        # WEBアプリのベースURLを使用（Host-first対応）
        web_base_url = self.config.api_base_url.rsplit('/api', 1)[0] if getattr(self.config, 'api_base_url', None) else "https://seraku.newton-x.net"
        company_subdomain = self.config.company_subdomain or (self.config.host.split('.')[0] if getattr(self.config, 'host', None) else "")
        
        if company_subdomain:
            return f"{web_base_url}/account/redirectadlogin?subdomain={company_subdomain}"
        else:
            return f"{web_base_url}/account/redirectadlogin"
    
    def _get_newtonx_token(self) -> Optional[str]:
        """
        NewtonXのWEBアプリからセッション情報を取得する
        
        Returns:
            セッション認証情報（取得できない場合はNone）
        """
        try:
            # セッションを作成してクッキーを管理
            session = requests.Session()
            session.headers.update({
                'User-Agent': 'NewtonX-ADK/0.10.5',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            })
            
            # 認証URLにアクセスしてセッションを確立（Host-first対応）
            web_base_url = self.config.api_base_url.rsplit('/api', 1)[0] if getattr(self.config, 'api_base_url', None) else "https://seraku.newton-x.net"
            subdomain = self.config.company_subdomain or (self.config.host.split('.')[0] if getattr(self.config, 'host', None) else "")
            auth_url = f"{web_base_url}/account/redirectadlogin" + (f"?subdomain={subdomain}" if subdomain else "")
            
            response = session.get(auth_url, allow_redirects=False, timeout=10)
            print(f"認証URLアクセス応答: {response.status_code}")
            
            # リダイレクト先にアクセスしてセッションを確立
            if response.status_code == 302:
                redirect_url = response.headers.get('Location')
                print(f"リダイレクト先: {redirect_url}")
                
                # リダイレクト先にアクセス
                redirect_response = session.get(redirect_url, timeout=10)
                print(f"リダイレクト先応答: {redirect_response.status_code}")
            
            # セッションクッキーを保存
            if session.cookies:
                print(f"セッションクッキー数: {len(session.cookies)}")
                for cookie_name in session.cookies.keys():
                    print(f"   クッキー: {cookie_name}")
                
                # セッション情報を保存
                self.session_cookies = dict(session.cookies)
                
                # セッション情報をtokensにも保存（認証ヘッダー生成のため）
                if not hasattr(self, 'tokens') or not self.tokens:
                    self.tokens = {}
                self.tokens['session_cookies'] = self.session_cookies
                
                # 可能なら内部アクセストークンも抽出して保存（後続API用のBearer）
                try:
                    access_token = self._get_access_token_from_session(session)
                    if access_token:
                        self.tokens['newtonx_access_token'] = access_token
                except Exception:
                    pass

                self._save_tokens()
                return access_token if 'access_token' in locals() else "session_authenticated"
            else:
                print("セッションクッキーが見つかりません")
                return None
                
        except Exception as e:
            print(f"セッション取得エラー: {e}")
            return None
    
    def _get_access_token_from_session(self, session: requests.Session) -> Optional[str]:
        """
        セッションからアクセストークンを取得する
        
        Args:
            session: 認証済みセッション
            
        Returns:
            アクセストークン（取得できない場合はNone）
        """
        try:
            # 認証コールバックURLをシミュレート（Host-first対応）
            web_base_url = self.config.api_base_url.rsplit('/api', 1)[0] if getattr(self.config, 'api_base_url', None) else "https://seraku.newton-x.net"
            # auth_callbackはブラウザ遷移でトークンがURLパラメータとして現れるため、
            # ADK側で固定URLを叩かず、以降のHTMLやAPI応答から抽出のみを試みる
            # （固定トークンのハードコード禁止）
            
            # まずはチャットページにアクセスして内部トークン痕跡を探す
            # ここではCookieが有効であれば必要な情報がHTMLに露出している場合がある
            # （存在しない場合は後段の別パターンで探索）
            
            # 別の方法として、チャットページにアクセスしてトークンを探す
            chat_url = f"{web_base_url}/aichat/chat"
            response = session.get(chat_url, timeout=10)
            print(f"チャットページアクセス応答: {response.status_code}")
            
            # レスポンスからアクセストークンを探す
            if response.status_code == 200:
                # HTMLレスポンスからトークンを探す
                token_pattern = r'"access_token":"([^"]+)"'
                match = re.search(token_pattern, response.text)
                if match:
                    access_token = match.group(1)
                    print(f"アクセストークンを発見（HTML）: {access_token[:50]}...")
                    return access_token
                
                # 別のパターンも試す
                token_pattern2 = r'access_token["\s]*:["\s]*["\']([^"\']+)["\']'
                match2 = re.search(token_pattern2, response.text)
                if match2:
                    access_token = match2.group(1)
                    print(f"アクセストークンを発見（パターン2）: {access_token[:50]}...")
                    return access_token
                
                # URLパラメータからトークンを探す
                token_pattern3 = r'access_token=([^&]+)'
                match3 = re.search(token_pattern3, response.text)
                if match3:
                    access_token = match3.group(1)
                    print(f"アクセストークンを発見（URLパラメータ）: {access_token[:50]}...")
                    return access_token
            
            print("アクセストークンが見つかりませんでした")
            return None
            
        except Exception as e:
            print(f"アクセストークン取得エラー: {e}")
            return None
    
    def get_user_info(self) -> Optional[Dict]:
        """
        ユーザー情報を取得する
        
        Returns:
            ユーザー情報の辞書
        """
        try:
            # NewtonXのAPIからユーザー情報を取得
            headers = self._get_headers()
            response = requests.get(
                f"{self.config.api_base_url}/user",
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"ユーザー情報取得エラー: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"ユーザー情報取得エラー: {e}")
            return None
    
    def get_headers(self) -> Dict[str, str]:
        """
        認証ヘッダーを取得する（公開メソッド）
        
        Returns:
            認証ヘッダーの辞書
        """
        return self._get_headers()
    
    def _get_headers(self) -> Dict[str, str]:
        """
        認証ヘッダーを取得する（WEB版同等: Cookie + Bearer + X-XSRF-TOKEN + Origin/Referer）
        """
        headers: Dict[str, str] = {
            'Content-Type': 'application/json',
            'User-Agent': 'NewtonX-ADK/0.10.5',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
        }
        # Origin/Referer
        web_base_url = self.config.api_base_url.rsplit('/api', 1)[0] if getattr(self.config, 'api_base_url', None) else "https://seraku.newton-x.net"
        headers['Origin'] = web_base_url
        headers['Referer'] = f"{web_base_url}/aichat/chat"

        # 認証情報の収集
        session_cookies: Optional[Dict[str, str]] = None
        bearer: Optional[str] = None

        # PAT（ADK用トークン）があれば最優先で使用
        try:
            pat = getattr(self.config, 'personal_access_token', '') or ''
            if isinstance(pat, str) and pat.strip():
                bearer = pat.strip()
        except Exception:
            pass

        # 1) メモリ上のtokens（PATが未設定のときだけ探索）
        if not bearer and self.tokens:
            if isinstance(self.tokens.get('session_cookies'), dict) and self.tokens['session_cookies']:
                session_cookies = self.tokens['session_cookies']
                self.session_cookies = session_cookies
            # NewtonX内部トークンを優先。なければMSALのアクセストークン
            if self.tokens.get('newtonx_access_token'):
                bearer = self.tokens['newtonx_access_token']
            elif self.tokens.get('access_token'):
                bearer = self.tokens['access_token']

        # 2) self.session_cookies
        if not session_cookies and self.session_cookies:
            session_cookies = self.session_cookies

        # 3) トークンファイル
        if (not session_cookies or not bearer) and hasattr(self, 'token_file_path') and self.token_file_path.exists():
            try:
                with open(self.token_file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if not session_cookies and isinstance(data.get('session_cookies'), dict):
                        session_cookies = data['session_cookies']
                    if not bearer:
                        if data.get('newtonx_access_token'):
                            bearer = data['newtonx_access_token']
                        elif data.get('access_token'):
                            bearer = data['access_token']
            except Exception:
                pass

        # Cookie ヘッダー（PAT のみで十分な場合もあるため任意）
        if session_cookies and not bearer:
            # 重要Cookieのみ送出（順序維持）
            allow_keys = ['XSRF-TOKEN', 'laravel_session', 'ai_user', 'ai_session']
            filtered = {k: v for k, v in session_cookies.items() if k in allow_keys}
            if filtered:
                cookie_string = '; '.join([f"{k}={v}" for k, v in filtered.items()])
                headers['Cookie'] = cookie_string
                # XSRF
                if 'XSRF-TOKEN' in filtered:
                    try:
                        headers['X-XSRF-TOKEN'] = urllib.parse.unquote(filtered['XSRF-TOKEN'])
                    except Exception:
                        headers['X-XSRF-TOKEN'] = filtered['XSRF-TOKEN']

        # Bearer
        if bearer:
            headers['Authorization'] = f"Bearer {bearer}"

        return headers

    def set_newtonx_access_token(self, token: str) -> None:
        """NewtonX内部アクセストークンを保存する"""
        if not isinstance(token, str) or '|' not in token:
            return
        if not self.tokens:
            self.tokens = {}
        self.tokens['newtonx_access_token'] = token
        self._save_tokens()

    def bootstrap_session(self) -> bool:
        """/available -> /company -> /user を順に叩いてセッションを安定化する"""
        try:
            base = getattr(self.config, 'api_base_url', None) or "https://seraku.newton-x.net/api"
            base = base.rstrip('/')

            # セッションでCookieを更新しながらアクセス
            session = requests.Session()

            # ヘッダー構築（CookieはSessionに載せるため除外して再構築）
            headers = self._get_headers()
            cookie_header = headers.pop('Cookie', None)
            session.headers.update(headers)
            # Cookieをセッションに移す
            if cookie_header:
                try:
                    for pair in cookie_header.split(';'):
                        if '=' in pair:
                            name, val = pair.strip().split('=', 1)
                            session.cookies.set(name, val)
                except Exception:
                    pass

            ok = True
            for ep in ['/available', '/company', '/user']:
                url = f"{base}{ep}"
                resp = session.get(url, timeout=10)
                if resp.status_code not in (200, 202):
                    ok = False
                    break

            # Cookie更新を反映
            new_cookies = requests.utils.dict_from_cookiejar(session.cookies)
            if new_cookies:
                self.session_cookies = new_cookies
                if not self.tokens:
                    self.tokens = {}
                self.tokens['session_cookies'] = self.session_cookies
                self._save_tokens()

            # 可能なら内部アクセストークンも抽出して保存（後続API用のBearer）
            try:
                access_token = self._get_access_token_from_session(session)
                if access_token:
                    if not self.tokens:
                        self.tokens = {}
                    self.tokens['newtonx_access_token'] = access_token
                    self._save_tokens()
            except Exception:
                pass

            return ok
        except Exception:
            return False
    
    def _establish_newtonx_session(self) -> bool:
        """
        NewtonXのセッションを確立する（EntraID認証前）
        
        Returns:
            セッション確立成功の場合True
        """
        try:
            print("NewtonXセッションを確立中...")
            
            # セッションを作成
            session = requests.Session()
            session.headers.update({
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8',
                'Accept-Encoding': 'gzip, deflate, br, zstd',
                'Connection': 'keep-alive',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'none',
                'Sec-Fetch-User': '?1',
                'Upgrade-Insecure-Requests': '1'
            })
            
            # 1. まずNewtonXのログインページにアクセスしてai_userとai_sessionのCookieを取得
            web_base_url = self.config.api_base_url.rsplit('/api', 1)[0] if getattr(self.config, 'api_base_url', None) else "https://seraku.newton-x.net"
            login_url = f"{web_base_url}/login"
            
            print(f"NewtonXログインページにアクセス: {login_url}")
            login_response = session.get(login_url, timeout=10)
            print(f"ログインページ応答: {login_response.status_code}")
            
            # ログインページのレスポンスヘッダーを確認
            if 'Set-Cookie' in login_response.headers:
                print("Set-Cookieヘッダー:")
                for cookie in login_response.headers.get_list('Set-Cookie'):
                    print(f"  {cookie}")
            
            # 2. ホームページにもアクセスしてCookieを取得
            home_url = f"{web_base_url}/"
            print(f"NewtonXホームページにアクセス: {home_url}")
            home_response = session.get(home_url, timeout=10)
            print(f"ホームページ応答: {home_response.status_code}")
            
            if 'Set-Cookie' in home_response.headers:
                print("ホームページのSet-Cookieヘッダー:")
                for cookie in home_response.headers.get_list('Set-Cookie'):
                    print(f"  {cookie}")
            
            # 3. NewtonXの認証URLにアクセス
            subdomain = self.config.company_subdomain or (self.config.host.split('.')[0] if getattr(self.config, 'host', None) else "")
            auth_url = f"{web_base_url}/account/redirectadlogin" + (f"?subdomain={subdomain}" if subdomain else "")
            
            print(f"NewtonX認証URL: {auth_url}")
            response = session.get(auth_url, allow_redirects=False, timeout=10)
            print(f"認証URL応答: {response.status_code}")
            
            # 4. リダイレクト先にアクセスしてセッションを確立
            if response.status_code == 302:
                redirect_url = response.headers.get('Location')
                print(f"リダイレクト先: {redirect_url}")
                
                # リダイレクト先にアクセス
                redirect_response = session.get(redirect_url, timeout=10)
                print(f"リダイレクト先応答: {redirect_response.status_code}")
            
            # 5. NewtonXのメインページにアクセス
            main_page_url = f"{web_base_url}/aichat/chat"
            print(f"NewtonXメインページにアクセス: {main_page_url}")
            main_page_response = session.get(main_page_url, timeout=10)
            print(f"メインページ応答: {main_page_response.status_code}")
            
            # セッションクッキーを保存
            if session.cookies:
                print(f"セッションクッキー数: {len(session.cookies)}")
                for cookie_name in session.cookies.keys():
                    print(f"   クッキー: {cookie_name}")
                
                # セッション情報を保存
                self.session_cookies = dict(session.cookies)
                
                # セッションクッキーをtokensにも保存（認証ヘッダー生成のため）
                if not hasattr(self, 'tokens') or not self.tokens:
                    self.tokens = {}
                self.tokens['session_cookies'] = self.session_cookies
                
                # 可能なら内部アクセストークンも抽出して保存（後続API用のBearer）
                try:
                    access_token = self._get_access_token_from_session(session)
                    if access_token:
                        self.tokens['newtonx_access_token'] = access_token
                except Exception:
                    pass

                self._save_tokens()
                print("✅ NewtonXセッションを確立しました")
                return True
            else:
                print("❌ セッションクッキーが取得できませんでした")
                return False
                
        except Exception as e:
            print(f"NewtonXセッション確立エラー: {e}")
            return False

    def get_access_token(self, scopes: Optional[list] = None, mode: Optional[str] = None) -> Optional[str]:
        """アクセストークン取得（ステルス優先: 内部トークン/既存Cookie/Azure CLI→MSAL）"""
        # 0) PAT が設定されていれば最優先でそれを返す（MSAL/Azureフローはスキップ）
        try:
            pat = getattr(self.config, 'personal_access_token', '') or ''
            if isinstance(pat, str) and pat.strip():
                return pat.strip()
        except Exception:
            pass
        # 1) NewtonX内部トークン優先（MSALスキップ）
        try:
            if self.tokens and self.tokens.get('newtonx_access_token'):
                if not self.session_cookies:
                    try:
                        self._establish_newtonx_session()
                    except Exception:
                        pass
                try:
                    self.bootstrap_session()
                except Exception:
                    pass
                return self.tokens['newtonx_access_token']
        except Exception:
            pass

        # 2) 既存のセッションCookieでブートストラップ可能ならMSAL無しで通す
        try:
            if self.session_cookies:
                self.bootstrap_session()
                return 'session_authenticated'
        except Exception:
            pass

        # 3) ステルスにNewtonXセッションを先に確立（EntraIDへの直接依存を避ける）
        try:
            if self._establish_newtonx_session():
                try:
                    self.bootstrap_session()
                except Exception:
                    pass
                return 'session_authenticated'
        except Exception:
            pass

        # 4) それでも必要な場合に限り、構成モードに従ってトークン取得
        picked_scopes = self._choose_scopes(scopes)
        token = self._acquire_token(picked_scopes, mode=mode)
        # 取得後はセッションを整える（失敗しても無視）
        try:
            if not self.session_cookies:
                self._establish_newtonx_session()
            self.bootstrap_session()
        except Exception:
            pass
        return token
    
    def logout(self) -> None:
        """ログアウトを実行する"""
        self.tokens = {}
        self.session_cookies = {}
        if self.token_file_path.exists():
            self.token_file_path.unlink()
        # MSALキャッシュも削除
        try:
            token_parent = Path(self.config.token_file).expanduser().parent
            cache_path = token_parent / 'msal_cache.bin'
            if cache_path.exists():
                cache_path.unlink()
        except Exception:
            pass
        print("ログアウトしました。")