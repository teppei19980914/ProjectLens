"""
NewtonX エージェント開発キット (NewtonX ADK)

NewtonX API を簡単に扱うための Python ライブラリです。
"""

try:
    # PEP 621: バージョンは pyproject.toml の project.version を正とする
    from importlib.metadata import version as _pkg_version  # Python 3.8+: importlib-metadata バックポート不要
    __version__ = _pkg_version("newtonx-adk")
except Exception:
    # パッケージ未インストール環境などでは暫定値
    __version__ = "0.0.0"
__author__ = "NewtonX Team"

from .client import NewtonXClient
from .config import ConfigManager, ADKConfig
from .auth import AuthManager
from .exceptions import (
    NewtonXError,
    AuthenticationError,
    APIError,
    ConfigurationError,
    FileUploadError,
    ChatError
)

__all__ = [
    "NewtonXClient",
    "ConfigManager",
    "ADKConfig",
    "AuthManager",
    "NewtonXError",
    "AuthenticationError",
    "APIError",
    "ConfigurationError",
    "FileUploadError",
    "ChatError"
] 