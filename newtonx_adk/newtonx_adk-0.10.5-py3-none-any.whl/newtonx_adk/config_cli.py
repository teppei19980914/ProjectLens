#!/usr/bin/env python3
"""
NewtonX エージェント開発キット (NewtonX ADK) 設定CLI

Entra IDの識別子（tenant_id, client_id, object_id, domain）や
PKCE/認証オプション（use_pkce, redirect_uri, authority, auth_mode）を
対話なしで設定・表示・リセット・検証するCLIです。
"""

import argparse
import json
import sys
from typing import Any, Dict

from .config import ConfigManager


def _print_json(data: Dict[str, Any]) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2))


def cmd_show(args: argparse.Namespace) -> int:
    cm = ConfigManager()
    cfg = cm.get_config()
    _print_json(cfg.__dict__)
    return 0


def cmd_set(args: argparse.Namespace) -> int:
    cm = ConfigManager()

    # ID関連
    if any(v is not None for v in [args.tenant_id, args.client_id, args.object_id, args.domain]):
        cm.set_identity(
            tenant_id=args.tenant_id,
            client_id=args.client_id,
            object_id=args.object_id,
            domain=args.domain,
        )

    # 認証オプション
    if any(v is not None for v in [args.use_pkce, args.redirect_uri, args.authority, args.auth_mode]):
        cm.set_auth_options(
            use_pkce=args.use_pkce,
            redirect_uri=args.redirect_uri,
            authority=args.authority,
            auth_mode=args.auth_mode,
        )

    # Host-first（host指定時に派生値を自動導出）
    if getattr(args, 'host', None):
        cm.update_config(host=args.host)

    # API/その他
    updates: Dict[str, Any] = {}
    if args.host is not None:
        updates["host"] = args.host
    if args.api_base_url is not None:
        updates["api_base_url"] = args.api_base_url
    if args.company_subdomain is not None:
        updates["company_subdomain"] = args.company_subdomain
    if args.token_file is not None:
        updates["token_file"] = args.token_file
    if args.timeout is not None:
        updates["timeout"] = int(args.timeout)
    if getattr(args, 'use_object_id_auth', None) is not None:
        updates["use_object_id_auth"] = args.use_object_id_auth
    if updates:
        cm.update_config(**updates)
    
    # オブジェクトID認証の設定
    if getattr(args, 'use_object_id_auth', None) is not None:
        cm.set_auth_options(use_object_id_auth=args.use_object_id_auth)

    return cmd_show(args)


def cmd_reset(args: argparse.Namespace) -> int:
    cm = ConfigManager()
    # デフォルトへ戻す
    cm.update_config(
        api_base_url="https://seraku.newton-x.net/api",
        company_subdomain="",
        domain="",
        client_id="",
        tenant_id="",
        object_id="",
        client_secret="",
        auth_mode="device_code",
        use_pkce=True,
        use_object_id_auth=True,
        redirect_uri="http://localhost:8400",
        authority=None,
        token_file="~/.newtonx/tokens.json",
        chat_history_path="~/.newtonx/chats",
        config_file=str(cm.config_file),
        max_history_display=50,
        timeout=30,
        max_retries=3,
        default_assistant=None,
    )
    return cmd_show(args)


def cmd_validate(args: argparse.Namespace) -> int:
    cm = ConfigManager()
    cfg = cm.get_config()
    problems = []

    # Host-first バリデーション
    if not cfg.api_base_url:
        problems.append("api_base_url が未設定です（hostを設定すると自動計算されます）")
    else:
        if not cfg.api_base_url.rstrip('/').endswith('/api'):
            problems.append("api_base_url は /api で終わる必要があります（自動補正対象）")

    if not cfg.tenant_id:
        problems.append("tenant_id が未設定です")
    if not cfg.client_id:
        problems.append("client_id が未設定です")
    if not cfg.redirect_uri:
        problems.append("redirect_uri が未設定です")
    if cfg.use_pkce is False:
        problems.append("use_pkce はTrue推奨です")

    if problems:
        _print_json({"ok": False, "problems": problems})
        return 1
    _print_json({"ok": True})
    return 0


def _prompt(prompt: str, default: str | None = None, required: bool = False) -> str:
    while True:
        suffix = f" [{default}]" if default else ""
        val = input(f"{prompt}{suffix}: ").strip()
        if not val and default is not None:
            return default
        if val or not required:
            return val
        print("必須入力です。もう一度入力してください。")


def cmd_configure(args: argparse.Namespace) -> int:
    cm = ConfigManager()
    cfg = cm.get_config()

    print("NewtonX ADK 設定ウィザード (Ctrl-Cで中断)")
    print()

    tenant_id = _prompt("Tenant ID", cfg.tenant_id or None, required=True)
    client_id = _prompt("Client ID (Application ID)", cfg.client_id or None, required=True)
    object_id = _prompt("Object ID", cfg.object_id or None, required=False)
    domain = _prompt("Domain (e.g. contoso.onmicrosoft.com)", cfg.domain or None, required=False)
    redirect_uri = _prompt("Redirect URI", cfg.redirect_uri or "http://localhost:8400", required=True)
    use_pkce_str = _prompt("Use PKCE? (true/false)", "true" if cfg.use_pkce else "false", required=True)
    auth_mode = _prompt("Auth mode (interactive/device_code)", cfg.auth_mode or "interactive", required=True)

    use_pkce = str(use_pkce_str).lower() in ("1", "true", "yes", "on")

    cm.set_identity(tenant_id=tenant_id, client_id=client_id, object_id=object_id, domain=domain)
    cm.set_auth_options(use_pkce=use_pkce, redirect_uri=redirect_uri, auth_mode=auth_mode)

    print("\n設定を保存しました。現在の設定:")
    return cmd_show(args)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="newtonx-adk-config", description="NewtonX ADK 設定CLI")
    sub = p.add_subparsers(dest="command", required=True)

    # show
    sp_show = sub.add_parser("show", help="現在の設定をJSONで表示")
    sp_show.set_defaults(func=cmd_show)

    # set
    sp_set = sub.add_parser("set", help="設定の更新")
    sp_set.add_argument("--tenant-id")
    sp_set.add_argument("--client-id")
    sp_set.add_argument("--object-id")
    sp_set.add_argument("--domain")
    sp_set.add_argument("--host", help="NewtonXホスト名（例: seraku.newton-x.net）")
    sp_set.add_argument("--api-base-url")
    sp_set.add_argument("--company-subdomain")
    sp_set.add_argument("--token-file")
    sp_set.add_argument("--timeout", type=int)
    sp_set.add_argument("--use-pkce", type=lambda v: str(v).lower() in ("1","true","yes","on"))
    sp_set.add_argument("--use-object-id-auth", type=lambda v: str(v).lower() in ("1","true","yes","on"), help="オブジェクトID認証を使用（1段階認証）")
    sp_set.add_argument("--redirect-uri")
    sp_set.add_argument("--authority")
    sp_set.add_argument("--auth-mode", choices=["interactive","device_code"]) 
    sp_set.set_defaults(func=cmd_set)

    # reset
    sp_reset = sub.add_parser("reset", help="設定をデフォルトへ戻す")
    sp_reset.set_defaults(func=cmd_reset)

    # validate
    sp_validate = sub.add_parser("validate", help="設定の妥当性チェック")
    sp_validate.set_defaults(func=cmd_validate)

    # configure (interactive)
    sp_conf = sub.add_parser("configure", help="対話的に設定を登録")
    sp_conf.set_defaults(func=cmd_configure)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())


